Product: Sphere 60, October 2014

Designer: Emmanuel Patoux

Support:  http://forums.obrary.com/category/designs/sphere-60

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Here's a kind of puzzle that builds a sphere from 4 different pieces. The style of the pieces is inspired by the Eiffel Tower.  It is designed for 4mm MDF cut on a Laser Cutter.